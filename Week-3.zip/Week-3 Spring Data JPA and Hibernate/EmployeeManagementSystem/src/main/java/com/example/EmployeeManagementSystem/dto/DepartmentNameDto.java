package com.example.EmployeeManagementSystem.dto;

public class DepartmentNameDto {
    private String name;

    public DepartmentNameDto(String name) {
        this.name = name;
    }

    // Getters and setters
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
